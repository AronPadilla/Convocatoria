/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dba;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Usuario
 */
public class Metodos_sql {
    
    public static MYSQL conexion = new MYSQL();
    
    public static PreparedStatement sentencia_preparada;
    public static ResultSet resultado;
    public static String sql;
    public static int resultado_numero = 0;
    
    public int guardarUsuario(String cod_SIS, String nombre, String apellidos, String direccion, 
                       String telefono, String correo, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO estudiante(codigo_SIS, nombre,apellidos,direccion,telefono,correo_Institucional,contraseña) VALUE (?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, cod_SIS);
            sentencia_preparada.setString(2, nombre);
            sentencia_preparada.setString(3, apellidos);
            sentencia_preparada.setString(4, direccion);
            sentencia_preparada.setString(5, telefono);
            sentencia_preparada.setString(6, correo);
            sentencia_preparada.setString(7, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
   
    
    
    public static String buscarUsuarioRegistrado(String codigo_SIS, String Contraseña){
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT codigo_SIS, contraseña FROM estudiante WHERE codigo_SIS = '"+codigo_SIS+"' && contraseña = '"+ Contraseña +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "usuario encontrado";
            }else{
                busqueda_usuario = "usuario no encontrado";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }

    public static String buscarAdmRegistrado(String admi, String Contraseña){
        
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT administracion, contraseña FROM administracion WHERE administracion = '"+admi+"' && contraseña = '"+ Contraseña +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "administrador encontrado";
            }else{
                busqueda_usuario = "administrador no encontrado";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }
    public static String buscarAutoridadRegistrado(String autoridad, String Contraseña){
            String busqueda_usuario = null;
            Connection conexion = null;
        
         try {
              conexion = MYSQL.getConnection();
              String sentencia_buscar_usuario = ("SELECT autoridad, contraseña FROM autoridad WHERE autoridad = '"+autoridad+"' && contraseña = '"+ Contraseña +"' ");
             sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
             resultado = sentencia_preparada.executeQuery();
             if(resultado.next()){
                 busqueda_usuario = "autoridad encontrado";
             }else{
                 busqueda_usuario = "autoridad no encontrado";
            }
            
              conexion.close();
            
         } catch (Exception e) {
                System.out.println(e);
            }
         return busqueda_usuario;
    }
    
    public static String buscarSecretariaRegistrado(String secretaria, String Contraseña){
            String busqueda_usuario = null;
            Connection conexion = null;
        
         try {
              conexion = MYSQL.getConnection();
              String sentencia_buscar_usuario = ("SELECT secretaria, contraseña FROM secretaria WHERE secretaria = '"+secretaria+"' && contraseña = '"+ Contraseña +"' ");
             sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
             resultado = sentencia_preparada.executeQuery();
             if(resultado.next()){
                 busqueda_usuario = "secretaria encontrado";
             }else{
                 busqueda_usuario = "secretaria no encontrado";
            }
            
              conexion.close();
            
         } catch (Exception e) {
                System.out.println(e);
            }
         return busqueda_usuario;
    }
    
    public static String buscarTribunalRegistrado(String tribunal, String Contraseña){
            String busqueda_usuario = null;
            Connection conexion = null;
        
         try {
              conexion = MYSQL.getConnection();
              String sentencia_buscar_usuario = ("SELECT tribu, contraseña FROM tribunal WHERE tribu = '"+tribunal+"' && contraseña = '"+ Contraseña +"' ");
             sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
             resultado = sentencia_preparada.executeQuery();
             if(resultado.next()){
                 busqueda_usuario = "tribunal encontrado";
             }else{
                 busqueda_usuario = "tribunal no encontrado";
            }
            
              conexion.close();
            
         } catch (Exception e) {
                System.out.println(e);
            }
         return busqueda_usuario;
    }
    
    
    
    public static int PostularPizarra(String item, String cantidad,String hrs_academicas, String destino, String Cod_SIS, int habilitado){
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO pizarron(item, cantidad,hrs_academicas,destino,cod_SIS_pizarra,habilitado) VALUE (?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setString(2, cantidad);
            sentencia_preparada.setString(3, hrs_academicas);
            sentencia_preparada.setString(4, destino);
            sentencia_preparada.setString(5, Cod_SIS);
            sentencia_preparada.setInt(6, habilitado);
           
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public static int PostularLaboratorio(String item, String cantidad,String hrs_academicas, String auxiliatura, String codigo_aux, String Cod_SIS, int habilitado){
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO laboratorio(item, cantidad,hrs_academicas, auxiliatura, codigo_aux, cod_SIS_lab, habilitado) VALUE (?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setString(2, cantidad);
            sentencia_preparada.setString(3, hrs_academicas);
            sentencia_preparada.setString(4, auxiliatura);
            sentencia_preparada.setString(5, codigo_aux);
            sentencia_preparada.setString(6, Cod_SIS);
            sentencia_preparada.setInt(7, habilitado);
            
           
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    
    
    public int guardarAutoridad(String nombre, String apellidos, String autoridad, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO autoridad(nombre,apellidos,autoridad,contraseña) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, autoridad);
            sentencia_preparada.setString(4, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    
    public int guardarSecretaria(String nombre, String apellidos, String secretaria, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO secretaria(nombre,apellidos,secretaria,contraseña) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, secretaria);
            sentencia_preparada.setString(4, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    public int guardarTribunal(String nombre, String apellidos, String tribunal, String contraseña, String funcion){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO tribunal(nombre,apellidos,tribu,contraseña,funcion) VALUE (?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, tribunal);
            sentencia_preparada.setString(4, contraseña);
            sentencia_preparada.setString(5, funcion);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarAdmi(String nombre, String apellidos, String administracion, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO administracion(nombre,apellidos,administracion,contraseña) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellidos);
            sentencia_preparada.setString(3, administracion);
            sentencia_preparada.setString(4, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public static String buscarMateriaRegistrada(String abrev,String tabla, String codigo_SIS, String Item){
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT cod_SIS_"+abrev+", item FROM "+tabla+" WHERE cod_SIS_"+abrev+" = '"+codigo_SIS+"' && item = '"+ Item +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "materia encontrada";
            }else{
                busqueda_usuario = "materia no encontrada";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }
    
    public int guardarReqLabo(String item, int estudiante, int pensum, int titulo, int deudas, int SexSemestre, int aprobado, String Codigo, int aprob){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO requisitos_laboratorio(item_req,Estudiante,concluir_pensum,sin_titulo, sin_deudas, aprobar_sextoSemestre, aprobar_concursoMeritos, codigo_SIS_req_labo, aprobado_labo_req) VALUE (?,?,?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, estudiante);
            sentencia_preparada.setInt(3, pensum);
            sentencia_preparada.setInt(4, titulo);
            sentencia_preparada.setInt(5, deudas);
            sentencia_preparada.setInt(6, SexSemestre);
            sentencia_preparada.setInt(7, aprobado);
            sentencia_preparada.setString(8, Codigo);
            sentencia_preparada.setInt(9, aprob);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarDocLabo(String item, int ques_1, int ques_2, int ques_3, int ques_4, int ques_5, int ques_6, int ques_7, int ques_8, int ques_9, String Codigo, int aprob){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO documentos_laboratorio(Item_doc,solicitud,certificado_de_condicion, certificado_de_rendimiento, certificado_sin_titulo, carnet_identidad, certificado_biblioteca, resumen_CV, respaldo_CV,kardex,cod_SIS_doc, aprobado_labo_doc) VALUE (?,?,?,?,?,?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, ques_1);
            sentencia_preparada.setInt(3, ques_2);
            sentencia_preparada.setInt(4, ques_3);
            sentencia_preparada.setInt(5, ques_4);
            sentencia_preparada.setInt(6, ques_5);
            sentencia_preparada.setInt(7, ques_6);
            sentencia_preparada.setInt(8, ques_7);
            sentencia_preparada.setInt(9, ques_8);
            sentencia_preparada.setInt(10, ques_9);
            sentencia_preparada.setString(11, Codigo);
            sentencia_preparada.setInt(12, aprob);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarReqPiza(String item, int estudiante, int concluirPensum, int titulo, int aprobado, int deudas, int aprobar , String Codigo, int aprob){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO requisitos_pizarra (item_req,Estudiante,concluir_pensum,sin_titulo, aprobado_materia, sin_deudas, aprobar_concursoMeritos, codigo_SIS_req_pizarra, aprobado_piza_req) VALUE (?,?,?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, estudiante);
            sentencia_preparada.setInt(3, concluirPensum);
            sentencia_preparada.setInt(4, titulo);
            sentencia_preparada.setInt(5, aprobado);
            sentencia_preparada.setInt(6, deudas);
            sentencia_preparada.setInt(7, aprobar);
            sentencia_preparada.setString(8, Codigo);
            sentencia_preparada.setInt(9, aprob);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarMerLabo(String item, int prom_aprobacion, int prom_general, int auxiliar_laboratorio, int auxiliar_practicas, int auxiliar_otros, double cursos_participacion, int experiencia_operador, int certificacion_capacitacion , String Codigo){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO calificacion_meritos_labo (item,prom_aprobacion,prom_general,auxiliar_laboratorio, auxiliar_practicas, auxiliar_otros, cursos_participacion, experiencia_operador, certificacion_capacitacion, cod_SIS_mer) VALUE (?,?,?,?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, prom_aprobacion);
            sentencia_preparada.setInt(3, prom_general);
            sentencia_preparada.setInt(4, auxiliar_laboratorio);
            sentencia_preparada.setInt(5, auxiliar_practicas);
            sentencia_preparada.setInt(6, auxiliar_otros);
            sentencia_preparada.setDouble(7, cursos_participacion);
            sentencia_preparada.setInt(8, experiencia_operador);
            sentencia_preparada.setInt(9, certificacion_capacitacion);
            sentencia_preparada.setString(10, Codigo);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarDocPiza(String item, int ques_1, int ques_2, int ques_3, int ques_4, int ques_5, int ques_6, int ques_7, int ques_8, int ques_9, String Codigo, int aprob){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO documentos_pizarra(Item_doc,solicitud,kardex,certificado_de_condicion,certificado_de_rendimiento,certificado_sin_titulo,carnet_identidad,certificado_biblioteca,resumen_CV,respaldo_CV,cod_SIS_doc, aprobado_piza_doc) VALUE (?,?,?,?,?,?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, ques_1);
            sentencia_preparada.setInt(3, ques_2);
            sentencia_preparada.setInt(4, ques_3);
            sentencia_preparada.setInt(5, ques_4);
            sentencia_preparada.setInt(6, ques_5);
            sentencia_preparada.setInt(7, ques_6);
            sentencia_preparada.setInt(8, ques_7);
            sentencia_preparada.setInt(9, ques_8);
            sentencia_preparada.setInt(10, ques_9);
            sentencia_preparada.setString(11, Codigo);
            sentencia_preparada.setInt(12, aprob);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarConoPiza(String item, int examen_escrito, int examen_oral, String Codigo){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO calificacion_conocimientos_piza (item,examen_escrito,examen_oral, cod_SIS_conocimientos) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, examen_escrito);
            sentencia_preparada.setInt(3, examen_oral);
            sentencia_preparada.setString(4, Codigo);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarMerPiza(String item, int prom_aprobacion, int prom_general, int auxiliar_docente, int auxiliar_otros, int cursos_participacion, int experiencia_operador, String cod_SIS_mer , int experiencia_docente){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO calificacion_meritos_pi (item,prom_aprobacion,prom_general,auxiliar_docente, auxiliar_otros, cursos_participacion, experiencia_operador, cod_SIS_mer,experiencia_docente) VALUE (?,?,?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, prom_aprobacion);
            sentencia_preparada.setInt(3, prom_general);
            sentencia_preparada.setInt(4, auxiliar_docente);
            sentencia_preparada.setInt(5, auxiliar_otros);
            sentencia_preparada.setDouble(6, cursos_participacion);
            sentencia_preparada.setInt(7, experiencia_operador);
            sentencia_preparada.setString(8, cod_SIS_mer);
            sentencia_preparada.setInt(9, experiencia_docente);
            
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarConoLabo(String item, int res1, int res2, int res3, int res4, int res5, int res6, int res7_teo, int res7_prac, int res8, String Codigo){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO calificacion_conocimientos_labo(Item,adm_linux,redes_nivel_intermedio, Mysql, programacion_internet, aplicaciones_web, hardware_software, electronica_teorico, electronica_practico,didactica,cod_SIS_conocimientos) VALUE (?,?,?,?,?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setInt(2, res1);
            sentencia_preparada.setInt(3, res2);
            sentencia_preparada.setInt(4, res3);
            sentencia_preparada.setInt(5, res4);
            sentencia_preparada.setInt(6, res5);
            sentencia_preparada.setInt(7, res6);
            sentencia_preparada.setInt(8, res7_teo);
            sentencia_preparada.setInt(9, res7_prac);
            sentencia_preparada.setInt(10, res8);
            sentencia_preparada.setString(11, Codigo);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public int guardarNotasPiza(String item, String Codigo, double nota, int aprobado){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO tabla_notas_piza(Item, cod_SIS_notas, nota_final, aprobado) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setString(2, Codigo);
            sentencia_preparada.setDouble(3, nota);
            sentencia_preparada.setInt(4, aprobado);
        
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    
    public int guardarNotasLabo(String item, String Codigo, double nota, int aprobado){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO tabla_notas_labo(Item, cod_SIS_notas, nota_final, aprobado) VALUE (?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, item);
            sentencia_preparada.setString(2, Codigo);
            sentencia_preparada.setDouble(3, nota);
            sentencia_preparada.setInt(4, aprobado);
        
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public static String buscarPostCalificadoLabo(String codigo_SIS, String Item){
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT cod_SIS_conocimientos, item FROM calificacion_conocimientos_labo WHERE cod_SIS_conocimientos = '"+codigo_SIS+"' && item = '"+ Item +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "postulante encontrado";
            }else{
                busqueda_usuario = "postulante no encontrado";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }
    
    public int ActualizarNotas(String sql){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = sql;
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
    public static String buscarFuncion(String Tribu){
        String busqueda_tribunal = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT funcion,tribu  FROM tribunal WHERE tribu = '"+Tribu+"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_tribunal = resultado.getString("funcion");
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_tribunal;
    }
    
    
    
    public static boolean buscarPostCalificadoTabla(String codigo_SIS, String Item, String tabla){
        boolean busqueda_usuario = false;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT cod_SIS_notas, item FROM "+tabla+" WHERE cod_SIS_notas = '"+codigo_SIS+"' && item = '"+ Item +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = true;
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }
    
    public static boolean buscarMerito(String Codigo, String Item, String tabla){
        boolean busqueda_tribunal = false;
        Connection conexion = null;
        String cod = "";
        if(tabla == "calificacion_meritos_labo"){
            cod = "calificacion_meritos_labo";
        }else{
            cod = "calificacion_meritos_pi";
        }
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT "+cod+" FROM "+tabla+" WHERE "+cod+" = '"+Codigo+"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_tribunal = true;
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_tribunal;
    }
    
    public static boolean buscarItemLabo(String Codigo, String Item){
        boolean busqueda_tribunal = false;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT cod_SIS_lab, item, habilitado  FROM laboratorio WHERE  cod_SIS_lab= '"+Codigo+"' && item = '"+Item+"' && habilitado = 1");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_tribunal = true;
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_tribunal;
    }
    
    public static String buscarPostCalificadoPiza(String codigo_SIS, String Item){
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT cod_SIS_conocimientos, item FROM calificacion_conocimientos_piza WHERE cod_SIS_conocimientos = '"+codigo_SIS+"' && item = '"+ Item +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "postulante encontrado";
            }else{
                busqueda_usuario = "postulante no encontrado";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
        }
    
        
    
    
}





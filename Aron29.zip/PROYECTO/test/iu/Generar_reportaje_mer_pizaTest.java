/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iu;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Usuario
 */
public class Generar_reportaje_mer_pizaTest {
    
    public Generar_reportaje_mer_pizaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setFuncion method, of class Generar_reportaje_mer_piza.
     */
    @Test
    public void testSetFuncion() {
        System.out.println("setFuncion");
        String func = "";
        Generar_reportaje_mer_piza instance = new Generar_reportaje_mer_piza();
        instance.setFuncion(func);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Iniciar method, of class Generar_reportaje_mer_piza.
     */
    @Test
    public void testIniciar() {
        System.out.println("Iniciar");
        Generar_reportaje_mer_piza instance = new Generar_reportaje_mer_piza();
        instance.Iniciar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of verificarReq method, of class Generar_reportaje_mer_piza.
     */
    @Test
    public void testVerificarReq() {
        System.out.println("verificarReq");
        String item = "";
        Generar_reportaje_mer_piza instance = new Generar_reportaje_mer_piza();
        boolean expResult = false;
        boolean result = instance.verificarReq(item);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of verificarDoc method, of class Generar_reportaje_mer_piza.
     */
    @Test
    public void testVerificarDoc() {
        System.out.println("verificarDoc");
        String item = "";
        Generar_reportaje_mer_piza instance = new Generar_reportaje_mer_piza();
        boolean expResult = false;
        boolean result = instance.verificarDoc(item);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of verificarMer method, of class Generar_reportaje_mer_piza.
     */
    @Test
    public void testVerificarMer() {
        System.out.println("verificarMer");
        String item = "";
        Generar_reportaje_mer_piza instance = new Generar_reportaje_mer_piza();
        boolean expResult = false;
        boolean result = instance.verificarMer(item);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Generar_reportaje_mer_piza.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Generar_reportaje_mer_piza.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

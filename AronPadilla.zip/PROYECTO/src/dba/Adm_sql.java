/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dba;

import iu.Administracion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author padilla
 */
public class Adm_sql {
    public static MYSQL conexion = new MYSQL();
    public static PreparedStatement sentencia_preparada;
    public static ResultSet resultado;
    public static String sql;
    public static int resultado_numero = 0;
    public static String buscarAdmRegistrado(String admi, String Contraseña){
        
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT administracion, contraseña FROM administracion WHERE administracion = '"+admi+"' && contraseña = '"+ Contraseña +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "usuario encontrado";
            }else{
                busqueda_usuario = "usuario no encontrado";
            }
            
            conexion.close();
            
        } catch (SQLException e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dba;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Usuario
 */
public class Metodos_sql {
    
    public static MYSQL conexion = new MYSQL();
    
    public static PreparedStatement sentencia_preparada;
    public static ResultSet resultado;
    public static String sql;
    public static int resultado_numero = 0;
    
    public int guardar(String cod_SIS, String nombre, String apellidos, String direccion, 
                       String telefono, String correo, String contraseña){
        
        int resultado = 0;
        Connection conexion = null;
        
        String sentencia_guardar = ("INSERT INTO estudiante(codigo_SIS, nombre,apellidos,direccion,telefono,correo_Institucional,contraseña) VALUE (?,?,?,?,?,?,?)");
        
        try {
            conexion = MYSQL.getConnection();
            sentencia_preparada = conexion.prepareStatement(sentencia_guardar);
            sentencia_preparada.setString(1, cod_SIS);
            sentencia_preparada.setString(2, nombre);
            sentencia_preparada.setString(3, apellidos);
            sentencia_preparada.setString(4, direccion);
            sentencia_preparada.setString(5, telefono);
            sentencia_preparada.setString(6, correo);
            sentencia_preparada.setString(7, contraseña);
            
            resultado = sentencia_preparada.executeUpdate();
            sentencia_preparada.close();
            
            conexion.close();
            
        } catch (Exception e) {
            
            System.err.println(e);
        }
        return resultado;
    }
    
   
    
    
    public static String buscarUsuarioRegistrado(String codigo_SIS, String Contraseña){
        String busqueda_usuario = null;
        Connection conexion = null;
        
        try {
            conexion = MYSQL.getConnection();
            String sentencia_buscar_usuario = ("SELECT codigo_SIS, contraseña FROM estudiante WHERE codigo_SIS = '"+codigo_SIS+"' && contraseña = '"+ Contraseña +"' ");
            sentencia_preparada = conexion.prepareStatement(sentencia_buscar_usuario);
            resultado = sentencia_preparada.executeQuery();
            if(resultado.next()){
                busqueda_usuario = "usuario encontrado";
            }else{
                busqueda_usuario = "usuario no encontrado";
            }
            
            conexion.close();
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return busqueda_usuario;
    }

    
    
}
